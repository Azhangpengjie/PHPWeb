<?php 
include "Conn/conn.php";
header('Content-Type:text/html;charset=utf-8');
$UserName=$_GET['x'];
$sql=oci_parse($link,"select * from tb_user where regname = '$UserName'");
oci_execute($sql,OCI_COMMIT_ON_SUCCESS);
$lines = oci_fetch_all($sql,$result);
if ($lines>0){
	echo ("[<font color=red>".$UserName."</font>]已被注册！");
}
else{
	echo ("恭喜您!用户名[<font color=green>".$UserName."</font>]可以注册！");
}
?>
