<?php
	session_start();
	include "Conn/conn.php";
	header('Content-Type:text/html;charset=utf-8');
	$user_id = isset($_GET['user_id'])?$_GET['user_id']:null;
	$f_sql = "select * from tb_user where id = ".$user_id;
	$f_rst = oci_parse($link, $f_sql);
	oci_execute($f_rst,OCI_COMMIT_ON_SUCCESS);   
	$p_row = oci_fetch_all($f_rst,$rows);
	
	if($rows['FIG'] == 1||$rows['REGNAME'] == "admin"){
		echo "<script>alert('不允许删除管理员');
		history.go(-1)</script>";
		exit();
	}
    else{
    	$dsql = "delete from tb_user where id = ".$_GET['user_id'];
    	
		$drst = oci_parse($link,$dsql);
		oci_execute($drst,OCI_COMMIT_ON_SUCCESS); 
		 
		if($drst){
			echo "<script>alert('删除成功');location='browseuser.php';</script>";
			exit();
		}else{
			echo "<script>alert('删除失败');history.go(-1);</script>";
			exit();
		} 

    }
?> 



