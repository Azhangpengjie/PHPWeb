<?php         
	include "Conn/conn.php";
    $sql="delete from tb_tpsc where id=".$pic_id;
    $result=mysql_query($sql);
	if($result){
		echo "<script>alert('图片删除成功!');location='browse_pic.php';</script>";
	}
	else{	
		echo "<script>alert('图片删除操作失败!');history.go(-1);</script>";
	}
?> 



