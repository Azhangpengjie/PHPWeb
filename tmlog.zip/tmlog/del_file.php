<?php   
	  
	include "check_login.php";
	include "Conn/conn.php";
	$file_id = isset($_GET['file_id'])?$_GET['file_id']:null;
   
	if(!empty($file_id)){
		$sql1 = "delete from tb_article where id = ".$file_id;
		$rst1 = mysql_query($sql1);
		if($rst1)
			echo "<script>alert('博客文章已被删除!');location='file.php';</script>";
		else
			echo "<script>alert('删除失败!');history.go(-1);</script>";
	}
	else{	
		echo "<script>alert('博客文章删除操作失败!');history.go(-1);</script>";
	}	
?> 



