<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<HEAD>
<TITLE>团队介绍</TITLE>
<META http-equiv=Content-Type content="text/html; charset=utf-8">
<LINK href="CSS/style.css" type=text/css rel=stylesheet>
<script src="JS/check.js" language="javascript">
</script>
</HEAD>
<BODY style="MARGIN-TOP: 0px; VERTICAL-ALIGN: top; PADDING-TOP: 0px; TEXT-ALIGN: center"> 
<?php
$str=array("大","更","创","天","科","客","博","技","立","新");
$word=count($str);
$img='';
$pic='';
for($i=0;$i<4;$i++){
  $num=rand(0,$word-1);      //$word=$word*2-1
  $img=$img."<img src=' images/checkcode/".$num.".gif' width='16' height='16'>";    //显示随机图片
  $pic=$pic.$str[$num];    //将图片转换成数组中的文字
}
?>
  <TABLE width="757" align="center" cellPadding=0 cellSpacing=0 style="WIDTH: 755px"> 
    <TBODY> 
      <TR> <TD style="VERTICAL-ALIGN: bottom; HEIGHT: 6px" colSpan=3 background="images/F_head.jpg"> <table width="100%" height="149"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="51" align="right">
      <br>
      <table width="262" border="0" cellspacing="0" cellpadding="0">
            <tr align="left">
              <td width="26" height="20"><a href="index.php"></a></td>
              <td width="71" class="word_white"><a href="index.php"><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none">团队首页</span></a></td>
              <td width="87"><a href="file.php"><span  style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none">我的团队</span></a></td>
              <td width="55"><a href="<?php echo (!isset($_SESSION['username'])?'Regpro.php':'safe.php'); ?>"><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none"><?php echo (!isset($_SESSION['username'])?"团队注册":"安全退出"); ?></span></a></td>
              <td width="23">&nbsp;</td>
            </tr>
          </table>
      <br></td>
        </tr>
        <tr>
          <td height="66" align="right"><p>&nbsp;</p></td>
        </tr>
        <tr>
    <form name="form" method="post" action="checkuser.php">
          <td height="20" valign="baseline">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="32%" height="20" align="center" valign="baseline">&nbsp; </td>
                <td width="67%" align="left" valign="baseline" style="text-indent:10px;">
        <?php
        if(!isset($_SESSION['username'])){
      ?>
        用户名:
                  <input  name=txt_user size="10">
密码:
<input  name=txt_pwd type=password style="FONT-SIZE: 9pt; WIDTH: 65px" size="6">
验证码:
<input name="txt_yan" style="FONT-SIZE: 9pt; WIDTH: 65px" size="8">
<input type="hidden" name="txt_hyan" id="txt_hyan" value="<?php echo $pic;?>">
<?php echo $img; ?> &nbsp;
<input style="FONT-SIZE: 9pt"  type=submit value=登录 name=sub_dl onClick="return f_check(form)">
&nbsp; 
<?php
        }else{
      ?>
        <font color="red"><?php echo $_SESSION['username']; ?></font>&nbsp;&nbsp;小捷团队欢迎您的光临！！！当前时间：<font color="red"><?php echo date("Y-m-d l"); ?>
</font>
      <?php
        }
      ?>
</td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
      </td>
      </form>
        </tr>
      </table></TD> 
      </TR> 
      <TR> 
        <TD colSpan=3 valign="middle" style="BACKGROUND-IMAGE: url( images/bg.jpg); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center"> <TABLE height="304" cellPadding=0 cellSpacing=0 style="WIDTH: 224px"> 
            <TBODY class="UserPro"> 
              <TR> 
                <TD 
            style="left: 500px; HEIGHT: 20px; TEXT-ALIGN: center"><STRONG><SPAN 
            style="COLOR: #993300" >团队介绍</SPAN></STRONG></TD> 
              </TR> 
              <TR> 
                <TD style="WIDTH: 368px; HEIGHT: 302px" rowSpan=2> <TABLE 
            style="BORDER-RIGHT: black thin solid; BORDER-TOP: black thin solid; BORDER-LEFT: black thin solid; WIDTH: 369px; BORDER-BOTTOM: black thin solid" 
            align=center> 
                    <TBODY  > 
                      <TR  > 
                        <TD  style="TEXT-ALIGN: left;" colSpan=4 
                  rowSpan=4>&nbsp;&nbsp;&nbsp;&nbsp;团队介绍内容：
                          <BR> 
                            <br>
                          一、本团队成员来自不同学院多个专业。<br><br>
                          合理搭配能力强。<br><br>
                          具有一定的经济学、管理学、市场分析及营销方面的基础知识技能。<br><br>
                          团队成员多次获得一等奖学金、国奖等。<br><br>
                          责任心上进心强，具有很好的团队协作能力与社会实践能力。<br><br>
                          二、组员互相尊重。<br><br>
                        </TD> 
                        
                      </TR> 
                      <TR></TR> 
                      <TR></TR> 
                      <TR></TR> 
                      <TR> 
                        <TD style="HEIGHT: 8px; TEXT-ALIGN: center" colSpan=4><INPUT id=Button1 style="FONT-SIZE: 9pt" type=submit value=继续注册 name=Button1 onClick="window.location.href='Register.php'"> 
&nbsp; 
                          <INPUT id=Button2 style="FONT-SIZE: 9pt" type=submit value=返回 name=Button2 onClick="window.location.href='index.php'"></TD> 
                      </TR> 
                    </TBODY> 
                  </TABLE></TD> 
              </TR> 
              <TR></TR> 
            </TBODY> 
          </TABLE></TD> 
      </TR> 
    </TBODY> 
  </TABLE> 
</BODY>
</HTML>