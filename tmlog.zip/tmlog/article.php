<?php 
  session_start(); 
  include "Conn/conn.php"; 
  $file_id1=$_GET['file_id'];
  $bool = false;
$str=array("大","更","创","天","科","客","博","技","立","新");
$word=count($str);
$img='';
$pic='';
for($i=0;$i<4;$i++){
  $num=rand(0,$word-1);      //$word=$word*2-1
  $img=$img."<img src=' images/checkcode/".$num.".gif' width='16' height='16'>";    //显示随机图片
  $pic=$pic.$str[$num];    //将图片转换成数组中的文字
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="CSS/style.css"  rel="stylesheet">
<title>浏览成员作业</title>
<script src="JS/check.js" language="javascript">
</script>
<script language="javascript">
function r_check(){
if (document.myform.txt_content.value==""){
  alert("评论内容不能为空!");myform.txt_content.focus();return false;
}
}
function d_chk(urlstr){
  if(confirm("确定要删除选中的项目吗？一旦删除将不能恢复！")){
    return true;
  }
  else
    return false;   
}
function fri_chk(){
if(confirm("确定要删除选中的项目吗？一旦删除将不能恢复！")){
    return true;
  }
  else
    return false;   
}
</script>
</head>
<body style="MARGIN-TOP: 0px; VERTICAL-ALIGN: top; PADDING-TOP: 0px; TEXT-ALIGN: center"> 
<TABLE width="757" cellPadding=0 align="center"  cellSpacing=0 style="WIDTH: 755px"> 
  <TBODY> 
    <TR> 
      <TD style="VERTICAL-ALIGN: bottom; HEIGHT: 6px" colSpan=3>
    <table width="100%" height="149"  border="0" cellpadding="0" cellspacing="0" background="images/F_head.jpg">
        <tr>
          <td height="51" align="right">
      <br>
      <table width="262" border="0" cellspacing="0" cellpadding="0">
            <tr align="left">
              <td width="26" height="20"><a href="index.php"></a></td>
              <td width="71" class="word_white"><a href="index.php"><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none">首  页</span></a></td>
              <td width="87"><a href="file.php"><span  style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none">我的团队</span></a></td>
              <td width="55"><a href="<?php echo (!isset($_SESSION['username'])?'Regpro.php':'safe.php'); ?>"><span style="FONT-SIZE: 9pt; COLOR: #000000; TEXT-DECORATION: none"><?php echo (!isset($_SESSION['username'])?"团队注册":"安全退出"); ?></span></a></td>
              <td width="23">&nbsp;</td>
            </tr>
          </table>
      <br></td>
        </tr>
        <tr>
          <td height="66" align="right"><p>&nbsp;</p></td>
        </tr>
        <tr>
    <form name="form" method="post" action="checkuser.php">
          <td height="20" valign="baseline">
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="20" align="left" valign="baseline" style=" text-indent:50px;"> 
        <?php
        if(!isset($_SESSION['username'])){
      ?>
        用户名:
                  <input  name=txt_user size="10">
密码:
<input  name=txt_pwd type=password style="FONT-SIZE: 9pt; WIDTH: 65px" size="6">
验证码:
<input name="txt_yan" style="FONT-SIZE: 9pt; WIDTH: 65px" size="8">
<input type="hidden" name="txt_hyan" id="txt_hyan" value="<?php echo $pic;?>">
<?php echo $img; ?> &nbsp;
<input style="FONT-SIZE: 9pt"  type=submit value=登录 name=sub_dl onClick="return f_check(form)">
&nbsp; 
<?php
        }else{
      ?>
        <font color="red"><?php echo $_SESSION['username']; ?></font>&nbsp;&nbsp;小捷团队欢迎您的光临！！！当前时间：<font color="red"><?php echo date("Y-m-d l"); ?>
</font>
          <?php
        }
      ?></td>
                <td width="1%" align="center" valign="baseline">&nbsp;</td>
              </tr>
            </table> 
      </td>
      </form>
        </tr>
      </table>
    
    </TD> 
    </TR> 
    <TR> 
      <TD colSpan=3 valign="baseline" style="BACKGROUND-IMAGE: url( images/bg.jpg); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center"><br> 
        <br> 
        <table width="600" height="100%"  border="0" cellpadding="0" cellspacing="0" id="tid1"> 
          <tr> 
            <td height="130" align="center" valign="middle"><table width="560" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#9CC739" bgcolor="#FFFFFF"> 
                <tr align="left" colspan="2" > 
                  <td width="390" height="25" colspan="3" valign="top" bgcolor="#EFF7DE">&nbsp;<span class="tableBorder_LTR"> 作业内容</span> </td> 
                </tr> 
                <td align="center" valign="top" ><table width="480" border="0" cellpadding="0" cellspacing="0"> 
                      <tr> 
                        <td> <?php 
            $sql=oci_parse($link,"select * from tb_article where id = ".$file_id1);
            oci_execute($sql,OCI_COMMIT_ON_SUCCESS);
            $lines=oci_fetch_all($sql,$result);
             
              for($i = 0;$i < $lines;$i ++){
          ?> 
                          <table width="100%"  border="1" cellpadding="1" cellspacing="1" bordercolor="#D6E7A5" bgcolor="#FFFFFF" class="i_table"> 
                            <tr bgcolor="#FFFFFF"> 
                              <td width="14%" align="center">成员ID号</td> 
                              <td width="15%"><?php echo $result['ID'][$i]; ?></td> 
                              <td width="11%" align="center">作
                                者</td> 
                              <td width="18%"><?php echo $result['AUTHOR'][$i]; ?></td> 
                              <td width="12%" align="">发表时间</td> 
                              <td width="30%" height="40px"><?php echo $result['NOW'][$i]; ?></td> 
                            </tr> 
                            <tr bgcolor="#FFFFFF"> 
                              <td align="center"  height="40px">作业主题</td> 
                              <td colspan="5">&nbsp;&nbsp;<?php echo $result['TITLE'][$i]; ?></td> 
                            </tr> 
                            <tr bgcolor="#FFFFFF"> 
                              <td align="center" height="200px" width="400px">作业内容</td> 
                              <td colspan="4"><?php echo $result['CONTENT'][$i]; ?></td> 
                           
                            </tr> 
                          </table>
                          <?php
                        }
                        oci_free_statement($sql);
                         oci_close($link);
                          ?>

                        </td> 
                      </tr> 
                    </table></td> 
              </table></td> 
          </tr> 
         
       
      <!--  发表评论  -->
       
      <!-------------->
        </td>
          </tr> 
        </table></TD> 
    </TR>  
 
  </TBODY> 
</TABLE> 
</body>
</html>
