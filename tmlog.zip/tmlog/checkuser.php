<?php
header('Content-Type:text/html;charset=utf-8');
session_start();
include "Conn/conn.php";
$name=$_POST['txt_user'];
$pwd=$_POST['txt_pwd'];
$sql=oci_parse($link,"select * from tb_user where regname='$name' and regpwd='$pwd'");
oci_execute($sql,OCI_COMMIT_ON_SUCCESS);
$lines = oci_fetch_all($sql,$result);


if($lines > 0){

$_SESSION['username']=$name;

?>
<script language="javascript">
	alert("登录成功");window.location.href="file.php";
</script>
<?php
}else{
?>
<script language="javascript">
	alert("对不起，您输入的用户名或密码不正确，请重新输入!");
	window.location.href="index.php";
</script>
<?php
 oci_free_statement($sql);
       oci_close($link);

	}
?>