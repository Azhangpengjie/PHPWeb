<?php
session_start();
include "Conn/conn.php";
header('Content-Type:text/html;charset=utf-8');
if($_SESSION['username']="admin"){
$title=$_POST['txt_title'];
$content=$_POST['file'];
$now=date("Y-m-d");
$sql="insert into tb_public (title,content,pub_time) Values ('$title','$content','$now')";
$result=oci_parse($link,$sql);
oci_execute($result,OCI_COMMIT_ON_SUCCESS);
if($result){
	echo "<script>alert('恭喜您，你的公告发表成功!!!');window.location.href='managepub.php';</script>";
	exit();
}
else{
	echo "<script>alert('对不起，添加操作失败!!!');history.go(-1);</script>";
}
oci_free_statement($result);
     oci_close($link);
}
?>
