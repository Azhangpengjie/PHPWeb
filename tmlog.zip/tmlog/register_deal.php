<?php
session_start();
include "Conn/conn.php";
header('Content-Type:text/html;charset=utf-8');
$UserName='';
$UserName=$_POST['txt_regname'];
/*
*
$sql=oci_parse("select * from tb_user where regname = '$UserName'");
oci_execute($sql,OCI_DEFAULT);
$lines = oci_fetch_all($sql,$result);
if ($lines>0){
	echo ("<script>alert('用户名已被注册！');history.go(-1);</script>");
	exit();
}
*/
$_SESSION['username']=$_POST['txt_regname'];
$regname=$_POST['txt_regname'];
$regstudentnumber=$_POST['txt_regstudentnumber'];
$regpwd=$_POST['txt_regpwd'];
$regemail=$_POST['txt_regemail'];
$regsex=$_POST['txt_regsex'];
$regqq=$_POST['txt_regqq'];
$regtelephonenumber=$_POST['txt_regtelephonenumber'];
$regintroduce=$_POST['txt_regintroduce'];
	

$INS=oci_parse($link,"insert into tb_user(regname,regstudentnumber,regpwd,regemail,regsex,regqq,regtelephonenumber,regintroduce,fig) Values ('$regname','$regstudentnumber','$regpwd','$regemail','$regsex','$regqq','$regtelephonenumber','$regintroduce',0)");
	

	oci_execute($INS,OCI_COMMIT_ON_SUCCESS);
	 oci_free_statement($INS);
     oci_close($link);
	echo "<script> alert('用户注册成功！');</script>";
	echo "<script> window.location='file.php';</script>";

?>
