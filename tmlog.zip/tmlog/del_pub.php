<?php
	header('Content-Type:text/html;charset=utf-8');
	session_start();
	include "conn/conn.php";
	if( $_SESSION['username']="admin"){
		$dsql = "delete from tb_public where id = ".$_GET['id'];
		$drst = oci_parse($link,$dsql);
		oci_execute($drst,OCI_COMMIT_ON_SUCCESS);   
		if($drst){
			echo "<script>alert('删除成功');location='managepub.php';</script>";
			exit();
		}else{
			echo "<script>alert('删除失败');history.go(-1);</script>";
			exit();
		}
	}else{
		echo "<script>alert('非法链接');window.close();</script>";
		exit();
	}
?>