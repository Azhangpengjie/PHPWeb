<?php
header('Content-Type:text/html;charset=utf-8');
session_start();
include "Conn/conn.php";
$btn_tj = isset($_POST['btn_tj'])?$_POST['btn_tj']:null;
if(!empty($btn_tj)){
$title=$_POST['txt_title'];
$author=$_SESSION['username'];
$content=$_POST['file'];
$now=date("Y-m-d H:i:s");

$INS="insert into tb_article (title,content,author,now) Values ('{$title}','{$content}','{$author}','{$now}')";

$sql = oci_parse($link,$INS);

$result=oci_execute($sql,OCI_COMMIT_ON_SUCCESS);

if($result){
	echo "<script>alert('恭喜您，你的作业提交成功!!!');window.location.href='file.php';</script>";
}
else{
	echo "<script>alert('对不起，添加操作失败!!!');window.location.href='file.php';</script>";
}
	oci_free_statement($sql);
    oci_close($link);

}
?>
