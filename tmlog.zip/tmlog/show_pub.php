<?php
	header('Content-Type:text/html;charset=utf-8');
	session_start();
	include "conn/conn.php";
	$pubsql = "select * from tb_public where id= ".$_GET['id'];
	
	$pubrst = oci_parse($link,$pubsql);
	oci_execute($pubrst,OCI_DEFAULT); 
	$pub = oci_fetch_all($pubrst,$pubrow);
	for($i=0;$i<$pub;$i++){
	echo "内容是： ";
	echo $pubrow['CONTENT'][$i];
	}
?>