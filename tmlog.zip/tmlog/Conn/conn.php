<?php
$link = oci_connect('zpj', '123456','10.64.70.98:1521/xscjsid','utf8');
if(!$link){
	echo "error";
}
else{
	echo "  ";
}


/*
*
$link=mysql_connect("localhost:3306","root","");
mysql_select_db("db_tmlog",$link);
mysql_query("set names utf8");
*/
?>
