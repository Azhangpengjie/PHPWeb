<?php 

include "Conn/conn.php";
include "check_login.php";
$page = isset($_GET['page'])?$_GET['page']:1;

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=GB2312">
<link href="CSS/style.css" rel="stylesheet">
<title>我的作业</title>
<style type="text/css">
<!--
.style1 {color: #FF0000}
-->
</style>
</head>
<script src=" JS/menu.JS"></script>
<script src=" JS/UBBCode.JS"></script>
<script language="javascript">
function check(){
  if(myform.txt_title.value==""){
    alert("作业主题名称不允许为空！");myform.txt_title.focus();return false;
  }
  if(myform.file.value==""){
    alert("作业内容不允许为空！");myform.file.focus();return false;
  }
}
</script>
<body >
<div class=menuskin id=popmenu 
      onmouseover="clearhidemenu();highlightmenu(event,'on')" 
      onmouseout="highlightmenu(event,'off');dynamichide(event)"
    style="Z-index:100;position:absolute;">
</div>
<TABLE width="757" cellPadding=0 cellSpacing=0 style="WIDTH: 755px" align="center"> 
  <TBODY> 
    <TR> <TD style="VERTICAL-ALIGN: bottom; HEIGHT: 6px" colSpan=3> <TABLE 
      style="BACKGROUND-IMAGE: url( images/f_head.jpg); WIDTH: 760px; HEIGHT: 154px" 
      cellSpacing=0 cellPadding=0> <TBODY> 
            <TR> 
              <TD height="110" colspan="6" 
          style="VERTICAL-ALIGN: text-top; WIDTH: 80px; HEIGHT: 115px; TEXT-ALIGN: right"></TD> 
            </TR> 
            <TR> 
              <TD height="34" align="center" valign="middle">
        <TABLE style="WIDTH: 580px" VERTICAL-ALIGN: text-top; cellSpacing=0 cellPadding=0 align="center">
                  <TBODY>
                    <TR align="center" valign="middle">
           <TD style="WIDTH: 100px; COLOR: red;">欢迎您:&nbsp;<?php echo $_SESSION['username']; ?>&nbsp;&nbsp;</TD>
                      <TD style="WIDTH: 80px; COLOR: red;"><SPAN  style="FONT-SIZE: 9pt; COLOR: #cc0033"> </SPAN><a href="index.php">团队首页</a></TD>
                      <TD style="WIDTH: 80px; COLOR: red;"><a  onmouseover=showmenu(event,productmenu) onmouseout=delayhidemenu() class='navlink' style="CURSOR:hand" >作业管理</a></TD>
                      

                       <?php
            if( $_SESSION['username']=='admin'){
             ?>
             <TD style="WIDTH: 80px; COLOR: red;"><a  onmouseover=showmenu(event,myuser) onmouseout=delayhidemenu() class='navlink' style="CURSOR:hand" >管理员管理</a></TD> 
             <?php  
            }
            ?>
            <TD style="WIDTH: 80px; COLOR: red;"><a href="safe.php">退出登录</a></TD>
                    </TR>
                  </TBODY>
              </TABLE>        </TD> 
            </TR> 
          </TBODY> 
        </TABLE></TD> 
    </TR> 
    <TR> 
      <TD colSpan=3 valign="baseline" style="BACKGROUND-IMAGE: url( images/bg.jpg); VERTICAL-ALIGN: middle; HEIGHT: 450px; TEXT-ALIGN: center"><table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="451" align="center" valign="top">
      
      <table width="600" height="100%"  border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td height="130" align="center" valign="top"><?php if (empty($page)) {$page=1;}; ?>
<table width="560" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#9CC739" bgcolor="#FFFFFF">
                <tr align="left" colspan="2" >
                  <td width="390" height="25" colspan="3" valign="top" bgcolor="#EFF7DE"> <span class="tableBorder_LTR"> 查看我的作业 </span> </td>
                </tr>
                  <?php
            if ($page){
               $page_size=20;     //每页显示20条记录
               $query="select count(*) as total from tb_article where author = '".$_SESSION['username']."' order by id desc";   
              $result=oci_parse($link,$query);       //查询总的记录条数
              oci_execute($result,OCI_DEFAULT);
              $lines = oci_fetch_all($result,$user);

              $message_count=oci_result($result,5);       //为变量赋值
              $page_count=ceil($message_count/$page_size);    //根据记录总数除以每页显示的记录数求出所分的页数
              $offset=($page-1)*$page_size;     //计算下一页从第几条数据开始循环  
                
                $sql=oci_parse($link,"select id,title from tb_article where author = '".$_SESSION['username']."' order by id desc ");      
                oci_execute($sql,OCI_DEFAULT);
                $line = oci_fetch_all($sql,$info);
                
           ?>
                <tr>
                  <td height="31" align="center" valign="top" ><table width="500"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><table width="498"  border="0" cellspacing="0" cellpadding="0" valign="top">
                          <?php
                for($i = 0; $i < $line;$i ++){
              ?>
                          <tr>
                            <td width="498" align="left" valign="top"> &nbsp;&nbsp;&nbsp;
                            <a href="showmy.php?file_id=<?php echo $info['ID'][$i];?>"><?php echo $i."、".$info['TITLE'][$i];?></a> </td>
                          </tr>
                          <?php 
                }
              ?>
                      </table></td>
                    </tr>
                  </table></td>
                </tr>
               <?php //} 
               ?>
              </table>
              <table width="560" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr bgcolor="#EFF7DE">
                  <td width="33%">&nbsp;&nbsp;页次：<?php echo $page;?>/<?php echo $page_count;?>页
                    记录：<?php echo $message_count;?> 条&nbsp; </td>
                  <td width="67%" align="right" class="hongse01">
                          <?php
              if($page!=1)
               {
               echo  "<a href=myfiles.php?page=1>首页</a>&nbsp;";
               echo "<a href=myfiles.php?page=".($page-1).">上一页</a>&nbsp;";
               }
              if($page<$page_count)
               {
                echo "<a href=myfiles.php?page=".($page+1).">下一页</a>&nbsp;";
                echo  "<a href=myfiles.php?page=".$page_count.">尾页</a>";
               }
             } 
            ?>
                  </td>
                </tr>
              </table></td>
          </tr>
        </table>
      
      </td>
    </tr>
</table></TD> 
    </TR> 
  </TBODY> 
</TABLE> 
</body>
</html>
